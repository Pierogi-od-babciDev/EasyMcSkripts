@echo off
if not exist paper.jar (
    echo [EasyMcSkripts] Downloading Paper 1.21.3...
    powershell -Command "Invoke-WebRequest -Uri 'https://fill-data.papermc.io/v1/objects/87e973e1d338e869e7fdbc4b8fadc1579d7bb0246a0e0cf6e5700ace6c8bc17e/paper-1.21.3-83.jar' -OutFile 'paper.jar'"
)
if not exist plugins (
    mkdir plugins
)
if not exist plugins\Skript.jar (
    echo [EasyMcSkripts] Downloading Skript 2.10.2...
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://github.com/SkriptLang/Skript/releases/download/2.10.2/Skript-2.10.2.jar' -OutFile 'plugins\Skript.jar'"
)
if not exist plugins\SkBee.jar (
    echo [EasyMcSkripts] Downloading SkBee 3.13.3...
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://cdn.modrinth.com/data/a0tlbHZO/versions/ovrzmrpx/SkBee-3.13.3.jar?mr_download_reason=standalone&mr_game_version=1.21.3' -OutFile 'plugins\SkBee.jar'"
)
if not exist plugins\skript-reflect.jar (
    echo [EasyMcSkripts] Downloading skript-reflect...
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://www.spigotmc.org/resources/skript-reflect.82259/download?version=603876' -OutFile 'plugins\skript-reflect.jar'"
)
echo [EasyMcSkripts] Everything is ready! Starting server...
java -jar -Xmx2G -Xms2G paper.jar nogui
pause
